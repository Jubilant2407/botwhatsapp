const help = (prefix) => {
	return `🔰 𝐒𝐚𝐝𝐁𝐨𝐭𝐳 𝐌𝐞𝐧𝐮 🔰
┏━━━━━━━━━━━━━━━━━━━━┓
┃ *⚠️ NO SPAM! NO CALL!!! ⚠️*
┃      *LANGGAR AUTO BLOCK*
┣━━━━━━━━━━━━━━━━━━━━┛
┃⊱❥ OWNER : 𝐑𝐚𝐦𝐥𝐚𝐧
┃⊱❥ YOUTUBE : 𝐑𝐚𝐦𝐥𝐚𝐧 𝐂𝐡𝐚𝐧𝐧𝐞𝐥
┃⊱❥ PREFIX : 「 ${prefix} 」
┃⊱❥ VERSION : 1.0
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 𝑻𝒆𝒏𝒕𝒂𝒏𝒈 𝑩𝑶𝑻
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}info
┃➢ ${prefix}owner
┃➢ ${prefix}donasi
┃➢ ${prefix}blocklist
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 𝑴𝒆𝒏𝒖 𝑺𝑰𝑴𝑷𝑳𝑬
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}sticker
┃➢ ${prefix}sticker nobg
┃➢ ${prefix}toimg
┃➢ ${prefix}ttp
┃➢ ${prefix}tts
┃➢ ${prefix}nulis
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 𝑴𝒆𝒏𝒖 𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}tiktod
┃➢ ${prefix}ytmp3
┣━━━━━━━━━━━━━━━━━━━━┛
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 𝑴𝒆𝒏𝒖 𝑴𝑬𝑴𝑬
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}meme
┃➢ ${prefix}memeindo
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 𝑴𝒆𝒏𝒖 𝑮𝑹𝑶𝑼𝑷
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}admin
┃➢ ${prefix}welcome [1/0]
┃➢ ${prefix}add
┃➢ ${prefix}kick
┃➢ ${prefix}promote
┃➢ ${prefix}demote
┃➢ ${prefix}tagall
┃➢ ${prefix}tagall2
┃➢ ${prefix}tagall3
┃➢ ${prefix}linkgrup
┃➢ ${prefix}leave
┃➢ ${prefix}simih [1/0]
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 𝑴𝒆𝒏𝒖 𝑪𝑶𝑴𝑳𝑰 [ EMROR ]
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}loli
┃➢ ${prefix}nsfwloli
┣━━━━━━━━━━━━━━━━━━━━┛
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 𝑴𝒆𝒏𝒖 𝑶𝑻𝑯𝑬𝑹
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}quotes
┃➢ ${prefix}ssweb
┃➢ ${prefix}simi
┃➢ ${prefix}ocr
┃➢ ${prefix}wait
┃➢ ${prefix}tiktokstalk
┃➢ ${prefix}hilih
┃➢ ${prefix}ytstalk
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 𝑴𝒆𝒏𝒖 𝑶𝑾𝑵𝑬𝑹
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}setprefix
┃➢ ${prefix}bc
┃➢ ${prefix}clearall
┃➢ ${prefix}clone
┣━━━━━━━━━━━━━━━━━━━━┛
┃⟪ 𝑹𝑨𝑴𝑳𝑨𝑵𝑮𝑨𝑵𝑺 ⟫
┣━━━━━━━━━━━━━━━━━━━━┓
`
}

exports.help = help
